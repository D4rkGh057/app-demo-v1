export interface Product {
  name: string;
  soldUnits: number;
  price: number;
  image: string;
  id: string;
}
