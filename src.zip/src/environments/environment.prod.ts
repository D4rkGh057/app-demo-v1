export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAjmirqyxv565_2Lfg7CLJS_TfMJsBQa8g",
    authDomain: "app-dch-demo1.firebaseapp.com",
    projectId: "app-dch-demo1",
    storageBucket: "app-dch-demo1.appspot.com",
    messagingSenderId: "662507864187",
    appId: "1:662507864187:web:c7652938cd86c548a4e2de"
  }
};
