// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBK1rfp9RX8NLyR6k7-vLxgkSUaFbCW2mM",
    authDomain: "app-dfu-demo1.firebaseapp.com",
    projectId: "app-dfu-demo1",
    storageBucket: "app-dfu-demo1.appspot.com",
    messagingSenderId: "693480120295",
    appId: "1:693480120295:web:162ea2992a84627464a742"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
